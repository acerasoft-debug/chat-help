<?php
/**
 * Ürün sayfası
 * ------------
 * Perakendede satın alma kararını veren üç şey burada yan yana:
 *  1) fiyat + KDV/kargo bilgisi (PAngV §1: brüt fiyat, kargo bilgisi zorunlu),
 *  2) beden bazında GERÇEK stok (toptan satırındaki beden dökümünden geliyor),
 *  3) satıcının kim olduğu ve hangi hukuki rejimin geçerli olduğu
 *     (Händler → gewährleistung + widerruf, Privatverkäufer → yok).
 *
 * Üçüncüsü pazaryerlerinde genelde küçük puntoda saklanır; burada ödeme
 * düğmesinin hemen yanında duruyor. Hem DSA md. 30 (satıcı izlenebilirliği)
 * hem de basitçe doğru olan şey bu.
 */

declare(strict_types=1);

require_once __DIR__ . '/inc/view.php';
require_once __DIR__ . '/inc/copy.php';

$id = trim((string)($_GET['id'] ?? ''));
$p  = $id !== '' ? vr_product($id) : null;

if ($p === null) {
    /* Satılmış ya da yanlış yazılmış bir ürün adresi 404 SAYFASINA gidiyor.
       Burada kendi kısa mesajı vardı: "Nothing matches those filters. Try a
       wider price range, or clear the house filter." — mağaza ızgarasının
       boş sonuç metni, tek bir ürün adresinde hiçbir anlamı yok, üstelik
       ekranda arama kutusu ve tek bir öneri bile bırakmıyordu. 404 sayfası
       adresten model kodunu çıkarıp benzerlerini gösteriyor; tek parça
       satıldığında alıcının önüne konması gereken tam olarak o. */
    require __DIR__ . '/404.php';
    exit;
}

// Bu ürün Vault'ta mı? Öyleyse fiyat oradan gelir, kullanıcıyı oraya yolluyoruz.
$vaultLot = null;
foreach (vr_vault_lots(['include_sold' => true]) as $v) {
    if ($v['product']['id'] === $p['id']) { $vaultLot = $v; break; }
}

// Son bakılanlar çerezine ekle (görüntüleme kaydı yalnızca kullanıcının
// cihazında kalıyor; sunucuda profil oluşmuyor).
vr_seen_push((string)$p['id']);

$seller   = vr_product_seller($p);
$related  = vr_related($p, 4);
$soldOut  = (int)$p['stock'] < 1;
$vatRate  = (int)vr_config('vat_rate_bps', 1900) / 100;
$shipDe   = (array)vr_config('shipping')['de'];
$days     = (int)vr_config('return_days', 30);
$sizeErr  = !empty($_GET['nosize']);

vr_layout_start([
    'title'    => $p['brand'] . ' ' . vr_card_name($p),
    'desc'     => $p['brand'] . ' ' . vr_card_name($p) . ' — ' . vr_product_teaser($p),
    'og_image' => vr_img_dynamic(vr_product_image($p), 1400),
    'jsonld'   => [
        vr_jsonld_product($p, $vaultLot ? (int)$vaultLot['state']['cents'] : null),
        vr_jsonld_breadcrumbs([
            (string)vr_config('brand') => vr_url('/'),
            t('nav_shop')              => vr_url('shop.php'),
            $p['brand']                => vr_url('shop.php', ['brand' => $p['brand']]),
            vr_card_name($p)           => null,
        ]),
    ],
]);
?>
<section class="sec sec--tight">
  <div class="wrap">
    <?php vr_breadcrumbs([
        t('nav_shop')    => vr_url('shop.php'),
        $p['brand']      => vr_url('shop.php', ['brand' => $p['brand']]),
        vr_cat_label($p['cat']) => vr_url('shop.php', ['cat' => $p['cat']]),
        vr_card_name($p) => null,
    ]); ?>

    <div class="pdp">
      <!-- ------------------------------------------------------- görseller
           Her görsel kendi dosyasına giden bir bağlantı: JavaScript kapalıyken
           tıklayınca tam boy açılıyor. JS varsa aynı bağlantıyı yakalayıp
           büyüteç katmanında gösteriyoruz (assets/js). -->
      <?php
      /* Tek üründe çok renk (toptancının "8 colourways" satırı): her rengin
         kendi galerisi; renk seçilince o rengin galerisi görünür
         (bkz. vr_colour_sets, assets/js "renk → galeri"). JS yoksa ilk rengin
         galerisi görünür, diğer renklerin kareleri renk düğmesinin içinde. */
      $siblingsTop = vr_variant_siblings($p);
      /* Ürünün kendi renk galerileri varsa şerit yerine onlar: renk
         seçimi sayfada kalır, galeri değişir. */
      $csets = vr_colour_sets($p);
      $galleries = $csets ? array_map(fn($cs) => $cs['images'], $csets) : [vr_product_gallery($p, 5)];
      foreach ($galleries as $gi => $shots): ?>
      <div class="pdp__media<?= count($shots) > 1 ? ' pdp__media--multi' : '' ?>" data-gallery
           <?= $csets ? 'data-cset="' . $gi . '"' . ($gi > 0 ? ' hidden' : '') : '' ?>>
        <?php foreach ($shots as $i => $src):
            $box = count($shots) > 1 ? 0.8 : 1.0;
            $r   = (float)(vr_photo_shape_index()[$src]['r'] ?? 0);
            // Tek kareli üründe kutuyu fotoğrafa uyduruyoruz. Enlemesine bir
            // kareyi zorla 1:1'e sokmak, ürünün üstüne ve altına kocaman
            // bulanık şerit koymak demek — ürün sayfasında bunun mazereti yok.
            if (count($shots) === 1 && $r > 0) $box = max(0.62, min(1.5, $r));
            // Çok kareli galeride gerçek bir yatay kare (serili çekim, etiket
            // detayı) 4:5 yuvaya kırpılmaz: kendi oranında, iki sütunu kaplar.
            $wide = count($shots) > 1 && $r > 1.25;
            if ($wide) $box = min(1.9, $r);
            $styled = count($shots) === 1 || $wide;
            $alt = $p['brand'] . ' ' . $p['name'] . ($csets ? ' — ' . $csets[$gi]['label'] : '') . ($i > 0 ? ' — ' . ($i + 1) : '');
        ?>
          <a class="pdp__shot<?= $wide ? ' pdp__shot--wide' : '' ?>" href="<?= h(vr_img($src, 1400)) ?>" data-zoom
             <?= $styled ? 'style="aspect-ratio:' . h((string)round($box, 3)) . '"' : '' ?>
             aria-label="<?= te('zoom') ?>: <?= h($p['brand'] . ' ' . vr_card_name($p)) ?>">
            <?php vr_frame($src, [
                'box'    => $box,
                'w'      => 900,
                'widths' => [420, 600, 900, 1400],
                'sizes'  => '(max-width:940px) 96vw, 640px',
                'alt'    => $alt,
                'eager'  => $i === 0 && $gi === 0,
            ]); ?>
            <span class="pdp__zoom" aria-hidden="true"><?= vr_icon('search', 16) ?></span>
          </a>
        <?php endforeach; ?>
      </div>
      <?php endforeach; ?>

      <!-- ------------------------------------------------------- satın alma -->
      <div class="pdp__side">
        <div class="pdp__head">
          <div>
            <p class="pdp__brand">
              <a href="<?= h(vr_url('shop.php', ['brand' => $p['brand']])) ?>"><?= h(vr_brand_label((string)$p['brand'])) ?></a>
              <?php /* Katalog neredeyse tamamen erkek giyim. Kadın parçalar
                 aralarında hiçbir işaret olmadan duruyordu — kadın bir kot
                 pantolon, yanındaki on erkek kotla aynı görünüyordu. Yalnızca
                 kadın parça işaretleniyor; erkek varsayılan olduğu için her
                 karta etiket basmak gürültü olurdu. */ ?>
              <?php if (($p['audience'] ?? '') === 'women'): ?>
                <span class="pill" style="margin-left:8px"><?= te('audience_women') ?></span>
              <?php endif; ?>
            </p>
            <h1><?= h(vr_card_name($p)) ?></h1>
          </div>
          <?php vr_wish_button($p, true); ?>
        </div>

        <?php if ($vaultLot !== null): ?>
          <!-- Vault'taki bir parça: fiyatı plan belirliyor, satış oradan yürüyor -->
          <div class="notice" style="border-left-color:var(--ember)">
            <strong><?= te('nav_outlet') ?>.</strong>
            <?= te('vault_lede') ?>
          </div>
          <div class="pdp__price">
            <b><?= h(vr_money((int)$vaultLot['state']['cents'])) ?></b>
            <?php if ($vaultLot['state']['reference'] !== null): ?>
              <s><?= h(vr_money((int)$vaultLot['state']['reference'])) ?></s>
            <?php endif; ?>
          </div>
          <p class="pdp__vat"><?= te('vat_incl', ['rate' => $vatRate]) ?></p>
          <a class="btn btn--brass btn--block btn--lg" href="<?= h(vr_url('outlet.php', ['lot' => $vaultLot['lot_id']])) ?>">
            <span><?= $vaultLot['sold'] ? te('vault_gone') : te('vault_take_it', ['amount' => vr_money((int)$vaultLot['state']['cents'])]) ?></span>
          </a>

        <?php else: ?>
          <div class="pdp__price">
            <b><?= h(vr_money((int)$p['price_cents'])) ?></b>
            <?php /* Dünya alıcısı için gösterge karşılık — bağlayıcı fiyat EUR,
               etiket bunu söylüyor. Kur güncel değilse ya da ziyaretçi EUR
               bölgesindeyse hiç çıkmıyor (inc/fx.php). */
               $lx = vr_money_local((int)$p['price_cents']); if ($lx !== ''): ?>
              <span class="fx fx--pdp" title="<?= te('fx_note') ?>"><?= h($lx) ?><i><?= te('fx_note') ?></i></span>
            <?php endif; ?>
            <?php if (!empty($p['rrp_cents']) && (int)$p['rrp_cents'] > (int)$p['price_cents']): ?>
              <span class="was"><?= te('uvp') ?> <s><?= h(vr_money((int)$p['rrp_cents'])) ?></s></span>
              <span class="disc"><?= h(vr_discount_label($p)) ?></span>
            <?php endif; ?>
          </div>
          <?php if (!empty($p['rrp_cents']) && (int)$p['rrp_cents'] > (int)$p['price_cents']): ?>
            <p class="pdp__uvp"><?= te('uvp_note') ?></p>
          <?php endif; ?>
          <?php if (!empty($p['deal_ends'])): ?>
            <p class="pdp__deal"><span class="deal__pulse" aria-hidden="true"></span><?= te('deal_kicker') ?>
              <span class="pdp__dealcd"><?= te('deal_ends_in') ?> <b data-countdown="<?= (int)$p['deal_ends'] ?>">—</b></span></p>
          <?php endif; ?>
          <p class="pdp__vat">
            <?= te('vat_incl', ['rate' => $vatRate]) ?>
            <?php if ((int)($shipDe['free_over'] ?? 0) > 0): ?>
              · <?= te('free_ship_over', ['amount' => vr_money((int)$shipDe['free_over'])]) ?>
            <?php endif; ?>
          </p>

          <?php
          /* Renk şeridi.
             Toptancı beslemesi her rengi ayrı ürün olarak açtığı için vitrinde
             modelin tek karosu duruyor (bkz. vr_variant_index). Diğer renklere
             giden tek kapı burası — şerit olmazsa o satırlar erişilemez kalır. */
          $siblings = $csets ? [] : vr_variant_siblings($p);
          $pCols    = vr_product_colours($p);
          if (count($siblings) > 1): ?>
            <div class="swatches">
              <h2 class="panel__h">
                <span><?= te('select_colour', ['n' => count($siblings)]) ?></span>
                <?php if ($pCols): ?><span class="swatches__now"><?= h(vr_colour_label($pCols[0])) ?></span><?php endif; ?>
              </h2>
              <div class="swatches__row">
                <?php foreach ($siblings as $sv):
                    $on  = $sv['id'] === $p['id'];
                    $svCols = vr_product_colours($sv);
                    $col = $svCols ? $svCols[0] : vr_variant_colour($sv);
                    $lbl = $col !== '' ? vr_colour_label($col) : vr_card_name($sv);
                    /* Fotoğrafı olmayan çeşit — beslemede bir satırın kareleri
                       hiç gelmemiş. Üretilmiş grafik burada koyu bir kare olarak
                       çıkıyor ve "Light Blue" yazan yerde haki bir kutu duruyor:
                       rengi yanlış göstermektense hiç göstermemek doğru. */
                    $svImg  = vr_swatch_image($sv);
                    $svReal = str_starts_with($svImg, '/uploads/');
                ?>
                  <a class="swatch<?= $on ? ' is-on' : '' ?><?= (int)$sv['stock'] < 1 ? ' is-out' : '' ?>"
                     href="<?= h(vr_product_url($sv)) ?>" title="<?= h($lbl) ?>"
                     <?= $on ? 'aria-current="page"' : '' ?>>
                    <?php if ($svReal) {
                        vr_frame($svImg, ['w' => 180, 'widths' => [180, 300], 'sizes' => '62px']);
                    } else { ?>
                      <span class="fr swatch__none" aria-hidden="true"></span>
                    <?php } ?>
                    <span class="swatch__l"><?= h($lbl) ?></span>
                  </a>
                <?php endforeach; ?>
              </div>
            </div>
          <?php elseif (count($pCols) === 1): ?>
            <p class="colourline">
              <span class="cdot" style="background:<?= h(vr_colour_css($pCols[0])) ?>" aria-hidden="true"></span>
              <span class="colourline__k"><?= te('colour') ?></span>
              <span class="colourline__v"><?= h(vr_colour_label($pCols[0])) ?></span>
            </p>
          <?php endif; ?>

          <?php if (!empty($p['sizes_unconfirmed'])): ?>
            <?php /* Beden dökümüne güvenilmiyor: toptan besleme üst giyim paket
               eğrisini (S·M·L·XL·XXL) denim satırlarına da basmış. Denim bu
               sistemle ölçülmez. Hangi bedenin stokta olduğunu bilmediğimiz
               için yanlış beden göndermektense satırı satışa kapatıyoruz —
               ürün görünür kalıyor ki soran sorabilsin. */ ?>
            <div class="notice" style="margin-bottom:14px">
              <strong><?= te('size_unconfirmed_t') ?></strong><br><?= te('size_unconfirmed_b') ?>
            </div>
            <a class="btn btn--block btn--lg" href="<?= h(vr_url('contact.php')) ?>">
              <span><?= te('size_unconfirmed_cta') ?></span>
            </a>
          <?php elseif ($soldOut): ?>
            <span class="btn btn--block is-disabled"><span><?= te('sold_out') ?></span></span>
            <p style="font-size:12.5px;color:var(--muted)"><?= te('you_may_like') ?> ↓</p>
          <?php else: ?>
            <form method="post" action="<?= h(vr_url('cart.php')) ?>" data-needs-size>
              <?= vr_csrf_field() ?>
              <input type="hidden" name="action" value="add">
              <input type="hidden" name="pid" value="<?= h($p['id']) ?>">

              <?php if ($csets): ?>
                <div class="panel" style="border:0;padding-top:0;margin-bottom:20px">
                  <h2 class="panel__h">
                    <span><?= te('select_colour', ['n' => count($csets)]) ?></span>
                    <span class="swatches__now" data-cset-now><?= h(vr_colour_label($csets[0]['label'])) ?></span>
                  </h2>
                  <div class="cpics" role="radiogroup" aria-label="<?= te('colour') ?>">
                    <?php foreach ($csets as $ci => $cs): ?>
                      <label class="cpic" title="<?= h(vr_colour_label($cs['label']) . ($cs['code'] !== '' ? ' · ' . $cs['code'] : '')) ?>">
                        <input type="radio" name="colour" value="<?= h($cs['name']) ?>" data-cset="<?= $ci ?>"
                               data-cset-label="<?= h(vr_colour_label($cs['label'])) ?>"<?= $ci === 0 ? ' checked' : '' ?>>
                        <?php vr_frame($cs['images'][0], ['w' => 180, 'widths' => [180, 300], 'sizes' => '64px', 'box' => 0.8]); ?>
                        <span class="cpic__l"><?= h(vr_colour_label($cs['label'])) ?></span>
                      </label>
                    <?php endforeach; ?>
                  </div>
                  <p class="field__err" data-colour-error hidden><?= te('choose_colour_err') ?></p>
                </div>
              <?php elseif (count($pCols) > 1):
                /* Satırın kendisi birden çok renk taşıyorsa seçim ŞART: sepet
                   renksiz eklemeyi reddediyor (vr_cart_colour). Eskiden şerit
                   varken bu kutu hiç basılmıyordu; müşteri renk seçemiyor,
                   sepete de ekleyemiyordu (12 Eki 2026). */ ?>
                <div class="panel" style="border:0;padding-top:0;margin-bottom:20px">
                  <h2 class="panel__h"><span><?= te('select_colour', ['n' => count($pCols)]) ?></span></h2>
                  <div class="cchips">
                    <?php foreach ($pCols as $c): ?>
                      <label class="cchip">
                        <input type="radio" name="colour" value="<?= h($c) ?>">
                        <span class="cdot" style="background:<?= h(vr_colour_css($c)) ?>" aria-hidden="true"></span>
                        <span><?= h(vr_colour_label($c)) ?></span>
                      </label>
                    <?php endforeach; ?>
                  </div>
                  <p class="field__err" data-colour-error hidden><?= te('choose_colour_err') ?></p>
                </div>
              <?php endif; ?>

              <?php
              $single = count($p['sizes']) === 1 && ($p['sizes'][0]['label'] ?? '') === 'ONE';
              if ($single): ?>
                <input type="hidden" name="size" value="ONE">
                <p class="pdp__vat" style="margin-bottom:14px">
                  <?= te('one_of_one') ?> · <?= (int)$p['stock'] <= 2 ? te('low_stock', ['n' => (int)$p['stock']]) : te('in_stock') ?>
                </p>
              <?php else: ?>
                <div class="panel" style="border:0;padding-top:0;margin-bottom:16px">
                  <h2 class="panel__h">
                    <span><?= te('select_size') ?></span>
                    <a class="link" href="<?= h(vr_url('size-guide.php', ['cat' => $p['cat']])) ?>">
                      <?= vr_icon('ruler', 14) ?> <?= te('size_guide') ?>
                    </a>
                  </h2>
                  <div class="sizes">
                    <?php /* Çipin altında bedenin KARŞILIĞI duruyor.
                       Kuru bir "M" alt giyimde yetersiz: kot pantolon S/M/L ile
                       ölçülmez. Karşılık uydurma değil, bu sitenin kendi beden
                       rehberinde yayımladığı satır (inc/sizing.php, tek kaynak):
                       alt giyimde M = IT 48 = 31 inç = 80–84 cm bel.
                       Üst giyimde ve alt giyimde eşleme FARKLI — üst bedeni
                       göğüsten, alt bedeni belden türüyor — o yüzden kategoriye
                       göre seçiliyor. Karşılığı olmayan etikette (ONE gibi)
                       hiçbir şey yazılmıyor. */ ?>
                    <?php foreach ($p['sizes'] as $s): ?>
                      <?php $eq = vr_size_equiv_line((string)$p['cat'], (string)$s['label']); ?>
                      <label class="size">
                        <input type="radio" name="size" value="<?= h($s['label']) ?>">
                        <?= h($s['label']) ?>
                        <?php if ($eq !== ''): ?><i class="size__eq"><?= h($eq) ?></i><?php endif; ?>
                      </label>
                    <?php endforeach; ?>
                  </div>
                  <p class="field__err" data-size-error <?= $sizeErr ? '' : 'hidden' ?>><?= te('size_missing') ?></p>
                </div>
              <?php endif; ?>

              <button class="btn btn--block btn--lg" type="submit"><span><?= te('add_to_cart') ?></span></button>
            </form>
          <?php endif; ?>
        <?php endif; ?>

        <!-- --------------------------------------------------- satıcı / hukuk -->
        <div class="panel panel--seller">
          <?= vr_icon($seller['type'] === 'private' ? 'user' : 'shield', 22) ?>
          <div>
            <?php /* Önce "Satan", sonra ad. Mağazanın kendi stoğunda tür satırı
                     adı tekrar ediyordu ("SARVESTO · SARVESTO stoğu"); orada
                     yalnızca "Satan" kalıyor. */ ?>
            <p class="seller__type"><?= te('sold_by') ?><?php
                if ($seller['type'] !== 'own') echo ' · ' . te('seller_' . $seller['type']);
                if ($seller['country'] !== '') echo ' · ' . h($seller['country']);
            ?></p>
            <p class="seller__name"><?= h($seller['name']) ?></p>
            <p class="seller__note"><?= te('seller_' . $seller['type'] . '_note', ['days' => $days]) ?></p>
          </div>
        </div>

        <!-- ------------------------------------------------------- herkunft -->
        <div class="panel">
          <h2><?= te('provenance') ?></h2>
          <p><?= te('provenance_body') ?></p>
        </div>

        <?php $copy = vr_product_copy($p); ?>
        <div class="panel">
          <h2><?= te('description') ?></h2>
          <?php if (($copy['lead'] ?? '') !== ''): ?>
            <p class="pdp__lead"><?= h($copy['lead']) ?></p>
          <?php endif; ?>
          <?php foreach ($copy['paras'] as $para): ?>
            <p><?= h($para) ?></p>
          <?php endforeach; ?>
        </div>

        <?php if ($copy['facts']): ?>
          <div class="panel">
            <h2><?= te('details') ?></h2>
            <dl class="dl">
              <?php foreach ($copy['facts'] as $label => $value): ?>
                <dt><?= h($label) ?></dt><dd><?= h($value) ?></dd>
              <?php endforeach; ?>
            </dl>
          </div>
        <?php endif; ?>

        <div class="panel">
          <h2><?= te('returns_title') ?></h2>
          <p><?= vr_icon('truck', 15) ?> <?= te('ships_in', ['days' => h((string)($shipDe['days'] ?? '1–3'))]) ?>
             · <?= h(vr_zone_label('de')) ?> <?= (int)($shipDe['cents'] ?? 0) === 0 ? te('shipping_free') : h(vr_money((int)$shipDe['cents'])) ?></p>
          <p><?= vr_icon('check', 15) ?> <?= te('order_next_3', ['days' => $days]) ?></p>
          <p style="font-size:12.5px;color:var(--muted)">
            <a class="link" href="<?= h(vr_url('legal/versand.php')) ?>"><?= te('legal_shipping') ?></a> ·
            <a class="link" href="<?= h(vr_url('legal/widerruf.php')) ?>"><?= te('legal_withdrawal') ?></a>
          </p>
        </div>

        <div class="panel">
          <h2><?= te('secure_payment') ?></h2>
          <p><?= vr_icon('lock', 15) ?> <?= te('payment_note') ?></p>
          <p style="font-size:11px;letter-spacing:.1em;color:var(--muted-2)"><?= h(implode(' · ', vr_payment_methods())) ?></p>
        </div>
      </div>
    </div>
  </div>
</section>

<?php if ($related): ?>
<section class="sec sec--tight">
  <div class="wrap">
    <?php vr_section_head(t('you_may_like'), '', vr_url('shop.php', ['brand' => $p['brand']])); ?>
    <?php vr_grid($related, ['class' => 'grid--4']); ?>
  </div>
</section>
<?php endif; ?>

<?php vr_seen_strip((string)$p['id']); ?>

<?php vr_layout_end(); ?>
